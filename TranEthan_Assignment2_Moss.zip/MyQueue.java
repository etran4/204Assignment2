/**
 * A utility class for converting to and from postfix notation
 * @author Ethan Tran
 */

import java.util.ArrayList;

public class MyQueue<T> implements QueueInterface<T> {
    private static int DEFAULT_CAPACITY = 5;

    private int size;
    private int capacity;
    private ArrayList<T> list;

    public MyQueue() {
        this(DEFAULT_CAPACITY);
    }

    @SuppressWarnings("unchecked")
    public MyQueue(int capacity) {
        this.capacity = capacity;
        this.size = 0;

        list = new ArrayList<>(capacity);
    }

    /**
     * Adds an element to the end of the Queue
     *
     * @param e the element to add to the end of the Queue
     * @return true if the add was successful
     * @throws QueueOverflowException if queue is full
     */
    public boolean enqueue(T entry) throws QueueOverflowException {
        if (isFull()) {
            throw new QueueOverflowException("");
        }
        list.add(entry);
        size++;
        return true;
    }

    /**
     * Deletes and returns the element at the front of the Queue
     *
     * @return the element at the front of the Queue
     * @throws QueueUnderflowException if queue is empty
     */
    public T dequeue() throws QueueUnderflowException {
        if (isEmpty()) {
            throw new QueueUnderflowException("");
        }

        T front = list.get(0);
        for (int index = 1; index < size; index++) {
            T entry = list.get(index);
            list.set(index - 1, entry);
        }

        size--;
        list.set(size, null);

        return front;
    }

    /**
     * Determines if Stack is full
     *
     * @return true if Stack is full, false if not
     */
    public boolean isFull() {
        return size == capacity;
    }

    /**
     * Determines if Stack is empty
     *
     * @return true if Stack is empty, false if not
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Number of elements in the Stack
     *
     * @return the number of elements in the Stack
     */
    public int size() {
        return size;
    }

    /**
     * Returns the string representation of the elements in the Queue,
     * the beginning of the string is the front of the queue
     *
     * @return string representation of the Queue with elements
     */
    public String toString() {
    	String outcome = "";

        for (T entry : list) {
            if (entry != null) {
                outcome += entry;
            }
        }
        return outcome;
    }

    /**
     * Returns the string representation of the elements in the Queue, the beginning
     * of the string is the front of the queue
     * Place the delimiter between all elements of the Queue
     *
     * @return string representation of the Queue with elements separated with the
     *         delimiter
     */
    public String toString(String delimiter) {
        
    	String outcome = "";

        for (T entry : list) {
            if (entry != null) {
                outcome += entry + delimiter;
            }
        }
        outcome = outcome.substring(0, outcome.length() - delimiter.length());
        return outcome;
    }

    /**
     * Fills the Queue with the elements of the ArrayList, First element in the
     * ArrayList
     * is the first element in the Queue
     * YOU MUST MAKE A COPY OF LIST AND ADD THOSE ELEMENTS TO THE QUEUE, if you use
     * the
     * list reference within your Queue, you will be allowing direct access to the
     * data of
     * your Queue causing a possible security breech.
     *
     * @param list elements to be added to the Queue
     * @throws QueueOverflowException if queue is full
     *
     */
    public void fill(ArrayList<T> list) throws QueueOverflowException {
        if (isFull() || list.size() + size > capacity) {
            throw new StackOverflowException("");
        }

        for (T entry : list) {
            enqueue(entry);
        }
    }
}