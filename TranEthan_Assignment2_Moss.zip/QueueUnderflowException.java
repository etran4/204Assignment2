/**
 *
 * @author Ethan Tran
 */
public class QueueUnderflowException extends RuntimeException {
    public QueueUnderflowException(String message) {
        super(message);
    }
}