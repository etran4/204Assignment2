/**
 * A utility class for converting to and from postfix notation
 *
 * @author Ethan Tran
 */

public class Notation {
	private static final char[] OPERATORS = { '/', '*', '+', '-' };

	private static boolean isOperator(char character) {
		for (char operand : OPERATORS) {
			if (character == operand) {
				return true;
			}
		}
		return false;
	}

	private static int getOperatorPrecedence(char operand) {
		for (int index = 0; index < OPERATORS.length; index++) {
			if (OPERATORS[index] == operand) {
				return (index < 2 ? 1 : 2);
			}
		}
		return 1;
	}

	/**
	 * Convert an infix expression into a postfix expression
	 *
	 * @param infix - the infix expression in string format
	 * @return the postfix expression in string format
	 * @throws InvalidNotationFormatException
	 */
	public static String convertInfixToPostfix(String infix) throws InvalidNotationFormatException {
		int length = infix.length();

		MyQueue<Character> postfix = new MyQueue<>(length);
		MyStack<Character> operators = new MyStack<>(length);

		for (int index = 0; index < length; index++) {
			char indexed = infix.charAt(index);

			if (indexed == ')') {
				char popped = operators.pop();
				try {
					while (popped != '(') {
						postfix.enqueue(popped);
						popped = operators.pop();
					}
				} catch (StackUnderflowException exception) {
					throw new InvalidNotationFormatException("");
				}                                         
			} else if (indexed == ' ') {
				continue;
			} else if (indexed == '(') {
				operators.push(indexed);
			} else if (Character.isDigit(indexed)) {
                postfix.enqueue(indexed);
			} else if (isOperator(indexed)) {
				if (!operators.isEmpty()) {
					char top = operators.top();
					if (isOperator(top) && getOperatorPrecedence(top) <= getOperatorPrecedence(indexed)) {
						postfix.enqueue(operators.pop());
					}
				}
				operators.push(indexed);
			} 
		}
		while (operators.size() > 0) {
			postfix.enqueue(operators.pop());
		}
		return postfix.toString();
	}

	/**
	 * Convert an infix expression into a postfix expression
	 *
	 * @param postfix - the postfix expression in string format
	 * @return the infix expression in string format
	 * @throws InvalidNotationFormatException - if the postfix expression format is
	 *                                        invalid
	 */
	public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException {
		int length = postfix.length();

		MyStack<String> infix = new MyStack<>(length);

		for (int index = 0; index < length; index++) {
			char indexed = postfix.charAt(index);

			if (Character.isDigit(indexed)) {
				infix.push(String.valueOf(indexed));
			} else if (indexed == ' ') {
				continue;
			} else if (isOperator(indexed)) {
				try {
					String operand1 = infix.pop();
					String operand2 = infix.pop();
					infix.push("(" + operand2 + indexed + operand1 + ")");

				} catch (StackUnderflowException exception) {
					throw new InvalidNotationFormatException(" ");
				}
			} 
		}
		if (infix.size() != 1) {
			throw new InvalidNotationFormatException("");
		}
		return infix.toString();
	}

	/**
	 * Evaluates a postfix expression from a string to a double
	 *
	 * @param postfix - the postfix expression in String format
	 * @return the evaluation of the postfix expression as a double
	 * @throws InvalidNotationFormatException - if the postfix expression format is
	 *                                        invalid
	 */
	public static double evaluatePostfixExpression(String postfix) {
        int length = postfix.length();

        MyStack<String> evaluated = new MyStack<>(length);

        for (int index = 0; index < length; index++) {
            char indexed = postfix.charAt(index);

            if (Character.isDigit(indexed)) {
                evaluated.push(String.valueOf(indexed));
            } else if (indexed == ' ') {
                continue;
            } else if (isOperator(indexed)) {
                try {
                    double operand1 = Double.valueOf(evaluated.pop());
                    double operand2 = Double.valueOf(evaluated.pop());

                    if (indexed == '*') {
                        evaluated.push(String.valueOf(operand2 * operand1));
                    } else if (indexed == '/') {
                        evaluated.push(String.valueOf(operand2 / operand1));
                    } else if (indexed == '+') {
                        evaluated.push(String.valueOf(operand2 + operand1));
                    } else if (indexed == '-') {
                        evaluated.push(String.valueOf(operand2 - operand1));
                    }
                } catch (StackUnderflowException e) {
                    throw new InvalidNotationFormatException("");
                }
            }
        }
        if (evaluated.size() != 1) {
            throw new InvalidNotationFormatException("");
        }
        return Double.valueOf(evaluated.toString());
    }
}