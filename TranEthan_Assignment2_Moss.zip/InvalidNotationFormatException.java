/**
 *
 * @author Ethan Tran
 */
public class InvalidNotationFormatException extends RuntimeException {
    public InvalidNotationFormatException(String message) {
        super(message);
    }
}