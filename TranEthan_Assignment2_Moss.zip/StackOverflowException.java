/**
 *
 * @author Ethan Tran
 */
public class StackOverflowException extends RuntimeException {
    public StackOverflowException(String message) {
        super(message);
    }
}